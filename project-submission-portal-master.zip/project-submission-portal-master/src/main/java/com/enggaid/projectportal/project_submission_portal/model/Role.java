package com.enggaid.projectportal.project_submission_portal.model;

import jakarta.persistence.Entity;


public enum Role {
    ADMIN,
    HOD,
    MENTOR,
    PROJECTHEAD;
}
