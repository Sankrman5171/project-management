package com.enggaid.projectportal.project_submission_portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalYearProjectSubmissionPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalYearProjectSubmissionPortalApplication.class, args);
	}

}
