package com.enggaid.projectportal.project_submission_portal.model;

public enum ProjectStatus {
    DRAFT,
    SUBMITTED,
    RESUBMITTED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED
}
