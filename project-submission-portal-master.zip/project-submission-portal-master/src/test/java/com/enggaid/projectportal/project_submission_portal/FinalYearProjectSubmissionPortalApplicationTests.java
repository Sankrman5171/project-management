package com.enggaid.projectportal.project_submission_portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalYearProjectSubmissionPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
